import * as _ from 'underscore';

export function undefOrNull(item: any): boolean {
	return _.isUndefined(item) || _.isNull(item);
}

export function undefOrNullOrEmpty(item: Array<any> | string): boolean {
	return _.isUndefined(item) || _.isNull(item) || item.length <= 0;
}
