import { Pipe, PipeTransform } from '@angular/core';
import { VideoDetail } from '../services/models/video-detail.model';

import * as _ from 'underscore';
import * as H from '../helpers/underscore.helper';

@Pipe({
    name: 'youtubeTitleFilter'
})
export class YoutubeTitleFilterPipe implements PipeTransform {
    transform(results: VideoDetail[], filterByName: string): VideoDetail[] {
        if (H.undefOrNull(results) || H.undefOrNull(filterByName)) {
            return results;
        }

        return _.filter(results, elem =>
            elem.title.toLowerCase().indexOf(filterByName.toLowerCase()) !== -1);
    }
}
