import { Pipe, PipeTransform } from '@angular/core';
import { VideoDetail } from '../services/models/video-detail.model';

import * as _ from 'underscore';
import * as H from '../helpers/underscore.helper';

@Pipe({
    name: 'youtubeFavouritesFilter'
})

export class YoutubeFavouritesFilterPipe implements PipeTransform {

	transform(results: VideoDetail[], favourites: string[], enabled: boolean): VideoDetail[] {

        if (H.undefOrNull(results) || H.undefOrNull(favourites) || !enabled) {
            return results;
        }

		return _.filter(results, elem => _.contains(favourites, elem.id));
    }
}
