import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YoutubeRequestResultComponent } from './youtube-request-result.component';

describe('YoutubeRequestResultComponent', () => {
  let component: YoutubeRequestResultComponent;
  let fixture: ComponentFixture<YoutubeRequestResultComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YoutubeRequestResultComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YoutubeRequestResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
