import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { VideoDetail } from '../../services/models/video-detail.model';

export class FavouriteChangedArgs {
	videoId: string;
	checked: boolean;
}

@Component({
	selector: 'app-youtube-request-result',
	templateUrl: './youtube-request-result.component.html',
	styleUrls: ['./youtube-request-result.component.css']
})
export class YoutubeRequestResultComponent implements OnInit {
	@Input() result: VideoDetail;
	@Output() favouriteChanged: EventEmitter<FavouriteChangedArgs> = new EventEmitter<FavouriteChangedArgs>();

	ngOnInit() {

	}

	saveVideo() {
		this.favouriteChanged.emit(<FavouriteChangedArgs>{
			videoId: this.result.id,
			checked: this.result.checked
		});
	}
}

