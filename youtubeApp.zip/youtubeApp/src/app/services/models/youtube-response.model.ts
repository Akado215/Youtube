import { VideoDetail } from './video-detail.model';

export class YoutubeResponse {
	videos: VideoDetail[];
	nextPageToken: string;
}
