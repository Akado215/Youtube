import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { VideoDetail } from './models/video-detail.model';
import { YoutubeResponse } from './models/youtube-response.model';

import * as _ from 'underscore';
import * as H from '../helpers/underscore.helper';

const YOUTUBE_API_KEY = 'AIzaSyDIByEVo86tMAyZA4MS5m30Ji8KmS1uJd0';
const YOUTUBE_API_URL = 'https://www.googleapis.com/youtube/v3/videos';

@Injectable({
	providedIn: 'root'
})
export class YoutubeRequestService {

	constructor(private http: HttpClient) { }

	list(pageToken: string = null): Observable<YoutubeResponse> {
		let params: string[] = [
			`part=snippet`,
			`maxResults=10`,
			`chart=mostPopular`,
			`key=${YOUTUBE_API_KEY}`
		];

		if (!H.undefOrNullOrEmpty(pageToken)) {
			params.push(`pageToken=${pageToken}`);
		}

		const queryUrl = `${YOUTUBE_API_URL}?${params.join('&')}`;

		return this.http.get(queryUrl).pipe(map(response => {
			return <YoutubeResponse>{
				nextPageToken: response['nextPageToken'],
				videos: _.map(response['items'], item =>
					<VideoDetail>{
						id: item.id,
						title: item.snippet.title,
						description: item.snippet.description,
						thumbnailUrl: item.snippet.thumbnails.high.url
					}
				)
			}
		}));
	}
}
