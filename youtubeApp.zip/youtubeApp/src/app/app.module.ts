import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { YoutubeFavouritesFilterPipe } from './pipes/youtube-favourites-filter.pipe';
import { YoutubeRequestResultComponent } from './components/youtube-request-result/youtube-request-result.component';
import { YoutubeTitleFilterPipe } from './pipes/youtube-title-filter.pipe';

@NgModule({
    declarations: [
        AppComponent,
        YoutubeRequestResultComponent,
        YoutubeTitleFilterPipe,
        YoutubeFavouritesFilterPipe
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        NgxPaginationModule,
        FormsModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
