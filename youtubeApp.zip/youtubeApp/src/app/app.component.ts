import { Component, OnInit } from '@angular/core';
import { YoutubeRequestService } from './services/youtube-request.service';
import { finalize } from 'rxjs/operators';
import { VideoDetail } from './services/models/video-detail.model';
import { FavouriteChangedArgs } from './components/youtube-request-result/youtube-request-result.component';

import * as _ from 'underscore';
import * as H from './helpers/underscore.helper';
import { PaginationInstance } from 'ngx-pagination';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})
export class AppComponent {

	readonly STORAGE_KEY_FAVOURITES: string = 'mega-sasha-project-favourites';

	paginationConfig: PaginationInstance = {
		id: 'listing_pagination',
		itemsPerPage: 10,
		currentPage: 1
	};

	favourites: string[] = [];
	favouritesEnabled: boolean = false;
	nextPageToken: string;

	results: VideoDetail[] = [];
	loading: boolean;
	message = '';

	config = {
		itemsPerPage: 10,
	};

	constructor(private youtube: YoutubeRequestService) { }

	ngOnInit() {

		const storedFavourites: string = localStorage.getItem(this.STORAGE_KEY_FAVOURITES);
		if (storedFavourites) {
			this.favourites.push(...storedFavourites.split(','));
		}

		this.loadVideos();
	}

	loadVideos() {
		this.loading = true;

		this.youtube.list(this.nextPageToken)
			.pipe(finalize(() => this.loading = false))
			.subscribe(
				response => {
					this.nextPageToken = response.nextPageToken;
					this.results.push(...response.videos);

					_.forEach(this.results, e => {
						e.checked = _.contains(this.favourites, e.id);
					});

					this.message = this.results.length === 0
						? 'Not found...' : `Top ${this.results.length} results:`;
				},
				err => {
					console.log(err);
				}
			);
	}

	onFavouriteChanged(data: FavouriteChangedArgs): void {
		if (data.checked) {
			this.favourites.push(data.videoId);
		}
		else {
			let elementIdx = _.indexOf(this.favourites, data.videoId);
			if (elementIdx !== -1) {
				this.favourites.splice(elementIdx, 1);
			}
		}

		localStorage.setItem(
			this.STORAGE_KEY_FAVOURITES,
			this.favourites.join(',')
		);
	}

	onPageChange(number: number) {
		this.paginationConfig.currentPage = number;
	}

	onPageBoundsCorrection(number: number) {
		this.paginationConfig.currentPage = number;
	}
}
